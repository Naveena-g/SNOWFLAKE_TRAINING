-- 1️⃣ Create table
CREATE OR REPLACE TABLE emp_base (
    EmpID INT,
    Name STRING,
    Department STRING,
    Salary INT
);

-- 2️⃣ Create stream
CREATE OR REPLACE STREAM emp_stream
ON TABLE emp_base;

-- 3️⃣ Insert rows
INSERT INTO emp_base VALUES (101, 'Amit', 'Sales', 50000);
INSERT INTO emp_base VALUES (102, 'Leena', 'HR', 60000);

-- 4️⃣ Update a row
UPDATE emp_base SET Salary = 55000 WHERE EmpID = 101;

-- 5️⃣ Delete a row
DELETE FROM emp_base WHERE EmpID = 102;

-- 6️⃣ Query the stream
SELECT 
    METADATA$ACTION,
    METADATA$ISUPDATE,
    EmpID, Name, Department, Salary
FROM emp_stream;
