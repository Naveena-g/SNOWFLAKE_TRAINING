create or replace task  customer_insert
warehouse =compute_wh
schedule='1 minute' as insert into customers(create_date) values(current_timestamp);

CREATE OR REPLACE TABLE customers (
    customer_id INT AUTOINCREMENT(1,1),
    first_name VARCHAR(40) DEFAULT 'JENNIFER',
    create_date DATE
);

truncate customers;


show tasks;

alter task customer_insert resume;


select * from customers;

create or replace task  customer_insert
warehouse =compute_wh
schedule='using cron */5 * * * * Asia/Kolkata' as insert into customers(create_date) values(current_timestamp);

create or replace task  customer_insert
warehouse =compute_wh
schedule='using cron */5 15-17 * * 1-5 Asia/Kolkata' as insert into customers(create_date) values(current_timestamp);

create or replace task  customer_insert
warehouse =compute_wh
schedule='using cron 0 * * * 1-5 Asia/Kolkata' as insert into customers(create_date) values(current_timestamp);

alter task customer_insert suspend;

CREATE OR REPLACE TABLE customers2 (
    customer_id INT ,
    first_name VARCHAR(40) DEFAULT 'JENNIFER',
    create_date DATE
);
CREATE OR REPLACE TABLE customers3 (
    customer_id INT ,
    first_name VARCHAR(40) DEFAULT 'JENNIFER',
    create_date DATE
);



create or replace task  customer_insert2
warehouse =compute_wh
after customer_insert
as insert into customers2 select * from customers;

create or replace task  customer_insert3
warehouse =compute_wh
after customer_insert2
as insert into customers3 select * from customers2;

alter task customer_insert3 resume;
alter task customer_insert2 resume;
alter task customer_insert resume;

show tasks;

select * from customers;
select * from customers2;
select * from customers3;

alter task customer_insert suspend;
alter task customer_insert2 suspend;
alter task customer_insert3 suspend;


select * from table (information_schema.task_history(task_name => 'customer_insert2',result_limit=>10));
















