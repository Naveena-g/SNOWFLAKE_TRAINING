create or replace role US_REGION_ROLE;
create or replace role EU_REGION_ROLE;

GRANT USAGE ON WAREHOUSE COMPUTE_WH TO US_REGION_ROLE;
 GRANT USAGE ON WAREHOUSE COMPUTE_WH TO EU_REGION_ROLE;
 GRANT USAGE ON DATABASE OUR_FIRST_DB TO US_REGION_ROLE;
 GRANT USAGE ON DATABASE OUR_FIRST_DB TO EU_REGION_ROLE;
 GRANT USAGE ON SCHEMA OUR_FIRST_DB.PUBLIC TO US_REGION_ROLE;
 GRANT USAGE ON SCHEMA OUR_FIRST_DB.PUBLIC TO EU_REGION_ROLE;

 create user us_user identified by 'admin123'
 default_role = us_region_role;
 create user eu_user identified by 'admin123'
 default_role =us_region_role;
 
drop user us_user;
drop user eu_user;

 grant role us_region_role to user us_user;
 grant role eu_region_role to user eu_user;

grant select on  our_first_db.public.SALES to role us_region_role;
grant select on  our_first_db.public.SALES to role eu_region_role;

  CREATE OR REPLACE TABLE SALES (
    SALE_ID INT,
    REGION STRING,
    CUSTOMER_NAME STRING,
    AMOUNT NUMBER(10,2)
);

INSERT INTO SALES VALUES
(1, 'US', 'John Smith', 1000),
(2, 'EU', 'Marie Curie', 1500),
(3, 'US', 'Alice Johnson', 2000),
(4, 'EU', 'Hans Muller', 1200);



CREATE OR REPLACE ROW ACCESS POLICY region_access_policy
  AS (reg STRING) RETURNS BOOLEAN ->
  CASE
      WHEN CURRENT_ROLE() = 'ACCOUNTADMIN' THEN TRUE
      WHEN CURRENT_ROLE() = 'US_REGION_ROLE' AND reg = 'US' THEN TRUE
      WHEN CURRENT_ROLE() = 'EU_REGION_ROLE' AND reg = 'EU' THEN TRUE
      ELSE FALSE
  END;

ALTER TABLE SALES
  ADD ROW ACCESS POLICY region_access_policy
  ON (REGION);