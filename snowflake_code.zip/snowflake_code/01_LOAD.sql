-- Use the warehouse
USE WAREHOUSE COMPUTE_WH;

-- Create database and switch into it
CREATE OR REPLACE DATABASE OUR_FIRST_DB;
USE DATABASE OUR_FIRST_DB;

-- Create schema and switch into it
CREATE OR REPLACE SCHEMA TRAINING;
USE SCHEMA TRAINING;

-- Create table
CREATE OR REPLACE TABLE DEMO (
    ID INT,
    NAME VARCHAR(30)
);

-- Verify table exists
SHOW TABLES;

-- Insert data
INSERT INTO DEMO VALUES
    (1,'RAM'),
    (2,'SHAM'),
    (3,'SUNIL');

-- Query the table
SELECT * FROM DEMO;

-- =====================================
CREATE OR REPLACE TRANSIENT TABLE orders_trans (
    order_id INT,
    customer_id INT,
    order_date DATE,
    amount NUMBER(10,2)
);
-- ============================

CREATE OR REPLACE FILE FORMAT my_csv_format
TYPE = 'CSV'
FIELD_OPTIONALLY_ENCLOSED_BY='"'
SKIP_HEADER=1
FIELD_DELIMITER=',';

-- =========================================

PUT file://C:\test\emploees_data.csv @%emp1trans;

COPY INTO emp_transient
FROM @%emp1trans
FILE_FORMAT = (FORMAT_NAME = my_csv_format)
ON_ERROR = 'CONTINUE';

-- ========================================================

PUT file://C:/test/products.csv @~;

COPY INTO temp_products
FROM @~/products.csv
FILE_FORMAT = (TYPE = 'CSV' FIELD_OPTIONALLY_ENCLOSED_BY='"' SKIP_HEADER=1);



