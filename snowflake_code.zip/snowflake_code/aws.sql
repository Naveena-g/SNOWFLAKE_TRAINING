create or replace stage aws_stage1 url ='s3://naveena-snowflakebkt43' credentials= (aws_key_id='AKIAXIEJSK4FUMVJH3MY' aws_secret_key='NySjYPz/txvshuYqfqXFpZWS0LtYaaHt/J0iFnE4 ');

list @aws_stage1;
SHOW STAGES;

CREATE OR REPLACE TABLE OrderDetails (
    Order_ID STRING,
    Amount FLOAT,
    Profit FLOAT,
    Quantity INT,
    Category STRING,
    Sub_Category STRING
);
copy into OrderDetails from @aws_stage1/OrderDetails.csv
file_format='my_csv_format'
purge=true;

select count(*)from OrderDetails;
select *from OrderDetails;


CREATE OR REPLACE TABLE employee_dataset (
    Employee_ID STRING,
    Name STRING,
    Age INT,
    Department STRING,
    Salary INT,
    Join_Date DATE,
    City STRING
);

copy into employee_dataset from @aws_stage1/employee_dataset.csv
file_format='my_csv_format'
purge=true;
select count(*)from employee_dataset;
select *from employee_dataset;


copy into @aws_stage1/employee_dataset_backup from employee_dataset
file_format=type=''

COPY INTO @aws_stage1/employee_dataset_backup
FROM employee_dataset
FILE_FORMAT = (TYPE = 'CSV' FIELD_DELIMITER = ',' HEADER = TRUE);