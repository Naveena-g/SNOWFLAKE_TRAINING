CREATE OR REPLACE STAGE OUR_FIRST_DB.PUBLIC.JSONSTAGE URL='s3://bucketsnowflake-jsondemo';

LIST @JSONSTAGE;

create or replace file format OUR_FIRST_DB.PUBLIC.JSONFORMAT TYPE = JSON;

create or replace TABLE JSON_RAW(raw_file variant);

copy into JSON_RAW from @JSONSTAGE file_format = JSONFORMAT;

select * from JSON_RAW;
select count(*) from JSON_RAW;


select raw_file:id::int as workers_ID,raw_file:city::string as workers_city from json_raw;
select raw_file:city::string as workers_city from json_raw;
SELECT raw_file:id::int Id,
       raw_file:first_name::string First_Name,
       raw_file:last_name::string Last_Name,
       raw_file:gender::string Gender,
       raw_file:city::string City,
       raw_file:job Job
FROM JSON_RAW;

SELECT raw_file:id::int Id,
       raw_file:first_name::string First_Name,
       raw_file:last_name::string Last_Name,
       raw_file:gender::string Gender,
       raw_file:city::string City,
       raw_file:job.salary::int Salary,
       raw_file:job.title::string Salary
FROM JSON_RAW;
SELECT raw_file:id::int Id,
       raw_file:first_name::string First_Name,
       raw_file:last_name::string Last_Name,
       raw_file:gender::string Gender,
       raw_file:city::string City,
       raw_file:job.salary::int Salary,
       raw_file:job.title::string Salary,
       array_size(raw_file:spoken_languages),
       array_size(raw_file:spoken_languages.language) as cou,
       array_size(raw_file:prev_company)
FROM JSON_RAW order by array_size(raw_file:spoken_languages.language) desc;



SELECT 
    raw_file:id::INT AS ID,
    raw_file:first_name::STRING AS First_Name,
    raw_file:last_name::STRING AS Last_Name,
    raw_file:gender::STRING AS Gender,
    raw_file:city::STRING AS City,
    raw_file:job.title::STRING AS Job_Title,
    raw_file:job.salary::FLOAT AS Salary,
    raw_file:spoken_languages[0].language::STRING AS Language_1,
    raw_file:spoken_languages[0].level::STRING AS Language_1_level,
    raw_file:spoken_languages[1].language::STRING AS Language_2,
    raw_file:spoken_languages[1].level::STRING AS Language_2_level,
    raw_file:prev_company[0]::STRING AS Prev_company_1,
    raw_file:prev_company[1]::STRING AS Prev_company_2
FROM JSON_RAW;


SELECT 
    raw_file:id::INT AS ID,
    raw_file:first_name::STRING AS First_Name,
    raw_file:last_name::STRING AS Last_Name,
    raw_file:gender::STRING AS Gender,
    raw_file:city::STRING AS City,
    raw_file:job.title::STRING AS Job_Title,
    raw_file:job.salary::FLOAT AS Salary,
    lang.value:language::STRING AS language,
    lang.value:level::STRING AS language_level,
    p.value:: string as company,
FROM table(flatten(raw_file:prev_company))as lang,
table(flatten(raw_file:prev_company)) as p order by ID;



SELECT 
    j.raw_file:id::INT AS worker_ID,
    j.raw_file:first_name::STRING AS first_name,
    j.raw_file:last_name::STRING AS last_name,
    j.raw_file:gender::STRING AS gender,
    j.raw_file:city::STRING AS city,
    j.raw_file:job.title::STRING AS job_title,
    j.raw_file:job.salary::FLOAT AS salary,
    sl.value:language::STRING AS language,
    sl.value:level::STRING AS language_level,
    j.raw_file:prev_company[0]::STRING AS Prev_company_1,
    j.raw_file:prev_company[1]::STRING AS Prev_company_2,
    j.raw_file:prev_company[2]::STRING AS Prev_company_3,
    pc.value::STRING AS previous_comp
FROM JSON_RAW j,
     LATERAL FLATTEN(INPUT => j.raw_file:spoken_languages) AS sl,
     LATERAL FLATTEN(INPUT => j.raw_file:prev_company, OUTER => TRUE) AS pc;








SELECT 
    j.raw_file:id::INT AS ID,
    j.raw_file:first_name::STRING AS First_Name,
    j.raw_file:last_name::STRING AS Last_Name,
    j.raw_file:gender::STRING AS Gender,
    j.raw_file:city::STRING AS City,
    j.raw_file:job.title::STRING AS Job_Title,
    j.raw_file:job.salary::FLOAT AS Salary,
    sl.value:language::STRING AS language,
    sl.value:level::STRING AS language_level,
    pc.value::STRING AS company
FROM JSON_RAW j,
     LATERAL FLATTEN(input => j.raw_file:spoken_languages) sl,
     LATERAL FLATTEN(input => j.raw_file:prev_company, outer => TRUE) pc
ORDER BY ID;


-- Flatten only spoken_languages
SELECT 
    j.raw_file:id::INT AS worker_ID,
    j.raw_file:first_name::STRING AS first_name,
    j.raw_file:last_name::STRING AS last_name,
    j.raw_file:gender::STRING AS gender,
    j.raw_file:city::STRING AS city,
    j.raw_file:job.title::STRING AS job_title,
    j.raw_file:job.salary::FLOAT AS salary,
    lang.value:language::STRING AS language,
    lang.value:level::STRING AS language_level,
    ARRAY_TO_STRING(j.raw_file:prev_company, ', ') AS previous_companies
FROM JSON_RAW j,
LATERAL FLATTEN(input => j.raw_file:spoken_languages) AS lang;
