CREATE OR REPLACE FILE FORMAT PARQUET_FORMAT
TYPE ='parquet';

create or replace stage pstage url ='s3://naveena-snowflakebkt43/PARQUET/recipes.parquet' FILE_FORMAT=PARQUET_FORMAT credentials= (aws_key_id='AKIAXIEJSK4FUMVJH3MY' aws_secret_key='NySjYPz/txvshuYqfqXFpZWS0LtYaaHt/J0iFnE4 ');

LIST @pstage;
SELECT $1 FROM @pstage;

SELECT
    $1:"AggregatedRating"::FLOAT AS aggregated_rating,
    $1:"AuthorId"::INT AS author_id,
    $1:"AuthorName"::STRING AS author_name,
    $1:"Calories"::FLOAT AS calories,
    $1:"CarbohydrateContent"::FLOAT AS carbohydrate_content,
    $1:"CholesterolContent"::FLOAT AS cholesterol_content,
    $1:"CookTime"::STRING AS cook_time,
    $1:"DatePublished"::TIMESTAMP_NTZ AS date_published,
    $1:"Description"::STRING AS description,
    $1:"FatContent"::FLOAT AS fat_content,
    $1:"FiberContent"::FLOAT AS fiber_content,
    $1:"Images"::ARRAY AS images,
    $1:"Keywords"::ARRAY AS keywords,
    $1:"Name"::STRING AS recipe_name,
    $1:"PrepTime"::STRING AS prep_time,
    $1:"ProteinContent"::FLOAT AS protein_content,
    $1:"RecipeCategory"::STRING AS recipe_category,
    $1:"RecipeId"::INT AS recipe_id,
    $1:"RecipeIngredientParts"::ARRAY AS ingredients,
    $1:"RecipeIngredientQuantities"::ARRAY AS ingredient_quantities,
    $1:"RecipeInstructions"::ARRAY AS instructions,
    $1:"RecipeServings"::INT AS servings,
    $1:"ReviewCount"::INT AS review_count,
    $1:"SaturatedFatContent"::FLOAT AS saturated_fat,
    $1:"SodiumContent"::FLOAT AS sodium_content,
    $1:"SugarContent"::FLOAT AS sugar_content,
    $1:"TotalTime"::STRING AS total_time
FROM
    @pstage;
show parameters like 'TIMEZONE';
alter session set timezone='Asia/Kolkata';

create or replace table parquet_data as 
SELECT
    $1:"AggregatedRating"::FLOAT AS aggregated_rating,
    $1:"AuthorId"::INT AS author_id,
    $1:"AuthorName"::STRING AS author_name,
    $1:"Calories"::FLOAT AS calories,
    $1:"CarbohydrateContent"::FLOAT AS carbohydrate_content,
    $1:"CholesterolContent"::FLOAT AS cholesterol_content,
    $1:"CookTime"::STRING AS cook_time,
    $1:"DatePublished"::TIMESTAMP_NTZ AS date_published,
    $1:"Description"::STRING AS description,
    $1:"FatContent"::FLOAT AS fat_content,
    $1:"FiberContent"::FLOAT AS fiber_content,
    $1:"Images"::ARRAY AS images,
    $1:"Keywords"::ARRAY AS keywords,
    $1:"Name"::STRING AS recipe_name,
    $1:"PrepTime"::STRING AS prep_time,
    $1:"ProteinContent"::FLOAT AS protein_content,
    $1:"RecipeCategory"::STRING AS recipe_category,
    $1:"RecipeId"::INT AS recipe_id,
    $1:"RecipeIngredientParts"::ARRAY AS ingredients,
    $1:"RecipeIngredientQuantities"::ARRAY AS ingredient_quantities,
    $1:"RecipeInstructions"::ARRAY AS instructions,
    $1:"RecipeServings"::INT AS servings,
    $1:"ReviewCount"::INT AS review_count,
    $1:"SaturatedFatContent"::FLOAT AS saturated_fat,
    $1:"SodiumContent"::FLOAT AS sodium_content,
    $1:"SugarContent"::FLOAT AS sugar_content,
    $1:"TotalTime"::STRING AS total_time
FROM
    @pstage;
select * from parquet_data;
create or replace table parq as select * from parquet_data ;

select * from parq;












