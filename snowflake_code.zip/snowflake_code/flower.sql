create or replace stage aws_stage1 url ='s3://naveena-snowflakebkt43' credentials= (aws_key_id='AKIAXIEJSK4FUMVJH3MY' aws_secret_key='NySjYPz/txvshuYqfqXFpZWS0LtYaaHt/J0iFnE4 ');

list @aws_stage1;
SHOW STAGES;

CREATE OR REPLACE TABLE flowers_dataset (
    FlowerID INT PRIMARY KEY,
    FlowerName VARCHAR(50),
    Color VARCHAR(20),
    PetalLength_cm FLOAT,
    PetalWidth_cm FLOAT,
    StemLength_cm INT,
    Price INT
);

copy into flowers_dataset from @aws_stage1/flowers_dataset.csv
file_format='my_csv_format'
purge=true;

select count(*)from flowers_dataset;
select *from flowers_dataset;

CREATE OR REPLACE TABLE flower_sales_dataset (
    SaleID INT PRIMARY KEY,
    FlowerID INT REFERENCES flowers_dataset(FlowerID),
    ShopName VARCHAR(100),
    City VARCHAR(50),
    Quantity INT,
    DiscountPercent INT,
    SaleAmount FLOAT
);


copy into flower_sales_dataset from @aws_stage1/flower_sales_dataset.csv
file_format='my_csv_format'
purge=true;

select count(*)from flower_sales_dataset;
select *from flower_sales_dataset;
