CREATE OR REPLACE TABLE customers (
    customer_id INT,
    customer_name STRING,
    city STRING,
    updated_at TIMESTAMP
);
-- target table

INSERT INTO customers VALUES
(1, 'John', 'New York', CURRENT_TIMESTAMP()),
(2, 'Emma', 'Chicago', CURRENT_TIMESTAMP()),
(3, 'Raj', 'Delhi', CURRENT_TIMESTAMP());

CREATE OR REPLACE TABLE customers_update (
    customer_id INT,
    customer_name STRING,
    city STRING
);
-- source table
INSERT INTO customers_update VALUES
(2, 'Emma Watson', 'Chicago'),   
(3, 'Raj', 'Mumbai'),            
(4, 'Sophia', 'London');

MERGE INTO customers AS target
USING customers_update AS source
ON target.customer_id = source.customer_id
WHEN MATCHED THEN
    UPDATE SET 
        target.customer_name = source.customer_name,
        target.city = source.city,
        target.updated_at = CURRENT_TIMESTAMP()
WHEN NOT MATCHED THEN
    INSERT (customer_id, customer_name, city, updated_at)
    VALUES (source.customer_id, source.customer_name, source.city, CURRENT_TIMESTAMP());

    

create or replace table sales_raw_staging(
  id varchar,
  product varchar,
  price varchar,
  amount varchar,
  store_id varchar);
  
create or replace table store_table(
  store_id number,
  location varchar,
  employees number);


INSERT INTO STORE_TABLE VALUES(1,'Chicago',33);
INSERT INTO STORE_TABLE VALUES(2,'London',12);

create or replace table sales_final_table(
  id int,
  product varchar,
  price number,
  amount int,
  store_id int,
  location varchar,
  employees int);

SHOW STREAMS LIKE 'SALES_STREAM';

create or replace stream sales_stream on table sales_raw_staging;

show streams;
desc stream sales_stream;

insert into sales_raw_staging 
    values
        (1,'Banana',1.99,1,1),
        (2,'Lemon',0.99,1,1),
        (3,'Apple',1.79,1,2),
        (4,'Orange Juice',1.89,1,2),
        (5,'Cereals',5.98,2,1);  
        
select * from sales_stream;

UPDATE sales_raw_staging
SET product   = 'guava',
    price     = 6.88,
    amount    = 8,
    store_id  = 9
WHERE id = 1;


INSERT INTO sales_final_table 
    SELECT 
    SA.id,
    SA.product,
    SA.price,
    SA.amount,
    ST.STORE_ID,
    ST.LOCATION, 
    ST.EMPLOYEES 
    FROM SALES_STREAM SA
    JOIN STORE_TABLE ST ON ST.STORE_ID=SA.STORE_ID ;
    
select * from sales_final_table;

-- merge into SALES_FINAL_TABLE F      
-- using SALES_STREAM S                
--    on  f.id = s.id                 
-- when matched 
--     and S.METADATA$ACTION ='INSERT'
--     and S.METADATA$ISUPDATE ='TRUE'       
--     then update 
--     set f.product = s.product,
--         f.price = s.price,
--         f.amount= s.amount,
--         f.store_id=s.store_id;
        
select * from sales_stream;

select * from sales_raw_staging order by id;

delete from sales_raw_staging where id =1;





-- merge into SALES_FINAL_TABLE F      
-- using SALES_STREAM S                
--    on  f.id = s.id          
-- when matched 
--     and S.METADATA$ACTION ='DELETE' 
--     and S.METADATA$ISUPDATE = 'FALSE'
--     then delete;
-- SELECT * FROM SALES_FINAL_TABLE;


create or replace task sales_final_table_cdc
warehouse=compute_wh
schedule ='1 minute'
as
merge into SALES_FINAL_TABLE F      
USING ( SELECT STRE.*,ST.location,ST.employees
        FROM SALES_STREAM STRE
        JOIN STORE_TABLE ST
        ON STRE.store_id = ST.store_id
       ) S
ON F.id=S.id
when matched                        -- DELETE condition
    and S.METADATA$ACTION ='DELETE' 
    and S.METADATA$ISUPDATE = 'FALSE'
    then delete                   
when matched                        -- UPDATE condition
    and S.METADATA$ACTION ='INSERT' 
    and S.METADATA$ISUPDATE  = 'TRUE'       
    then update 
    set f.product = s.product,
        f.price = s.price,
        f.amount= s.amount,
        f.store_id=s.store_id
when not matched 
    and S.METADATA$ACTION ='INSERT'
    then insert 
    (id,product,price,store_id,amount,employees,location)
    values
    (s.id, s.product,s.price,s.store_id,s.amount,s.employees,s.location);

insert into sales_raw_staging values (1,'Banana',1.99,1,1);
update sales_raw_staging set price =price *1.1 where id in (2,3);
delete  from sales_raw_staging where id = 4;

alter task sales_final_table_cdc resume;
SHOW TASKS SALES_FINAL_TABLE_CDC;

insert 

-- Use fully qualified name: <database>.<schema>.<task_name>
ALTER TASK OUR_FIRST_DB.PUBLIC.SALES_FINAL_TABLE_CDC RESUME;

SHOW TASKS LIKE 'SALES_FINAL_TABLE_CDC' IN SCHEMA OUR_FIRST_DB.PUBLIC;

SELECT *
FROM TABLE(INFORMATION_SCHEMA.TASK_HISTORY(
    task_name=>'OUR_FIRST_DB.PUBLIC.SALES_FINAL_TABLE_CDC',
    result_limit=>5
));
