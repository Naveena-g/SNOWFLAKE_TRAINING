-- 1.
CREATE OR REPLACE TRANSIENT TABLE orders_trans (
OrderID varchar,Product string,Qty int,Total int
);
CREATE OR REPLACE temporary TABLE orders_temp (
OrderID varchar,Product string,Qty int,Total int
);
CREATE OR REPLACE TABLE orders_perm (
OrderID varchar,Product string,Qty int,Total int
);

COPY INTO orders_temp
FROM @~/orders.csv
FILE_FORMAT = (FORMAT_NAME = my_csv_format)
ON_ERROR = 'CONTINUE';

-- 3. Create file format (if you haven't already)
CREATE OR REPLACE FILE FORMAT my_csv_format
  TYPE = 'CSV'
  FIELD_DELIMITER = ','
  SKIP_HEADER = 1
  NULL_IF = ('NULL','null')
  FIELD_OPTIONALLY_ENCLOSED_BY = '"';


  desc table orders_trans;

desc table orders_trans;
SHOW TABLES LIKE 'orders_%';



DELETE FROM orders_perm WHERE OrderID='O201';
DELETE FROM orders_trans WHERE OrderID='O201';
DELETE FROM orders_temp WHERE OrderID='O201';


SELECT * FROM orders_perm AT (OFFSET => -3600); 
SELECT * FROM orders_trans AT (OFFSET => -3600); 

select * from orders_temp;
select * from orders_trans;
select * from orders_temp;

INSERT INTO orders_perm
SELECT *
FROM orders_perm
AT (OFFSET => -3600)
WHERE OrderID = 'O201';

INSERT INTO orders_trans
SELECT *
FROM orders_trans
AT (OFFSET => -3600)
WHERE OrderID = 'O201';

  
-- =========================================================================================================================
-- 2.

CREATE OR REPLACE TRANSIENT TABLE cust_trans (
CustId varchar,CustName string,City string,CreditLimit int
);
CREATE OR REPLACE temporary TABLE cust_temp (
CustId varchar,CustName string,City string,CreditLimit int
);
INSERT INTO cust_temp (CUSTID, CUSTNAME, CITY, CREDITLIMIT) VALUES
('C001', 'Anil', 'Mumbai', 5000),
('C002', 'Rina', 'Bangalore', 60000),
('C003', 'Suresh', 'Delhi', 45000),
('C004', 'Meera', 'Pune', 70000),
('C005', 'Rohit', 'Chennai', 48000);

CREATE OR REPLACE TABLE cust_perm (
CustId varchar,CustName string,City string,CreditLimit int
);

select * from cust_temp;

show tables like 'cust_%';

SELECT * FROM cust_perm;
SELECT * FROM cust_trans;
SELECT * FROM cust_temp;

DELETE FROM cust_perm WHERE CustID = 'C002';
DELETE FROM cust_trans WHERE CustID = 'C002';
DELETE FROM cust_temp WHERE CustID = 'C002';

SELECT * FROM cust_perm AT (OFFSET => -600);
SELECT * FROM cust_trans AT (OFFSET => -600);

------------------------------------------------
-- 3.
CREATE OR REPLACE TABLE sales_perm (
    SalesID VARCHAR,
    CustomerName STRING,
    City STRING,
    Amount INT
);

CREATE OR REPLACE TRANSIENT TABLE sales_trans (
    SalesID VARCHAR,
    CustomerName STRING,
    City STRING,
    Amount INT
);

CREATE OR REPLACE TEMPORARY TABLE sales_temp (
    SalesID VARCHAR,
    CustomerName STRING,
    City STRING,
    Amount INT
);

show tables like 'sales_%';
SELECT * FROM sales_perm;
SELECT * FROM sales_trans;
SELECT * FROM sales_temp;

DELETE FROM sales_perm WHERE SalesID = 'S002';
DELETE FROM sales_trans WHERE SalesID = 'S002';
DELETE FROM sales_temp WHERE SalesID = 'S002';

SELECT * FROM sales_perm AT (OFFSET => -3600);
SELECT * FROM sales_trans AT (OFFSET => -3600);

INSERT INTO sales_perm
SELECT *
FROM sales_perm AT (OFFSET => -3600)
WHERE SalesID = 'S002';

INSERT INTO sales_trans
SELECT *
FROM sales_trans AT (OFFSET => -3600)
WHERE SalesID = 'S002';

SELECT * FROM sales_perm;
SELECT * FROM sales_trans;
SELECT * FROM sales_temp;

-- 4.


CREATE OR REPLACE TABLE inv_perm (
    ItemCode VARCHAR,
    Stock INT,
    Warehouse STRING
);

CREATE OR REPLACE TRANSIENT TABLE inv_trans (
    ItemCode VARCHAR,
    Stock INT,
    Warehouse STRING
);

CREATE OR REPLACE TEMPORARY TABLE inv_temp (
    ItemCode VARCHAR,
    Stock INT,
    Warehouse STRING
);

show tables like 'inv_%';
SELECT * FROM inv_perm;
SELECT * FROM inv_trans;
SELECT * FROM inv_temp;

DELETE FROM inv_perm WHERE ItemCode = 'I002';
DELETE FROM inv_trans WHERE ItemCode = 'I002';
DELETE FROM inv_temp WHERE ItemCode = 'I002';

SELECT * FROM inventory_perm AT (OFFSET => -3600);
SELECT * FROM inventory_trans AT (OFFSET => -3600);
INSERT INTO inventory_perm
SELECT *
FROM inventory_perm AT (OFFSET => -3600)
WHERE ItemCode = 'I002';

INSERT INTO inventory_trans
SELECT *
FROM inventory_trans AT (OFFSET => -3600)
WHERE ItemCode = 'I002';

-- 5.
CREATE OR REPLACE TABLE emp_perm (
    EmpID INT,
    Name STRING,
    Department STRING,
    Salary INT
);

CREATE OR REPLACE TRANSIENT TABLE emp_trans (
    EmpID INT,
    Name STRING,
    Department STRING,
    Salary INT
);

CREATE OR REPLACE TEMPORARY TABLE emp_temp (
    EmpID INT,
    Name STRING,
    Department STRING,
    Salary INT
);
show tables like 'emp_%';

SELECT * FROM emp_perm;
SELECT * FROM emp_trans;
SELECT * FROM emp_temp;

DELETE FROM emp_perm WHERE EmpID = 1002;
DELETE FROM emp_trans WHERE EmpID = 1002;
DELETE FROM emp_temp WHERE EmpID = 1002;

SELECT * FROM emp_perm;
SELECT * FROM emp_trans;
SELECT * FROM emp_temp;

SELECT * FROM emp_perm AT (OFFSET => -3600);
SELECT * FROM emp_trans AT (OFFSET => -3600);

INSERT INTO emp_perm
SELECT *
FROM emp_perm AT (OFFSET => -3600)
WHERE EmpID = 1002;

INSERT INTO emp_trans
SELECT *
FROM emp_trans AT (OFFSET => -3600)
WHERE EmpID = 1002;








