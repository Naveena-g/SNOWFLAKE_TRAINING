CREATE TABLE emp_base (EmpID int,Name varchar,Department varchar,Salary int);

CREATE or replace STREAM emp_stream 
ON TABLE emp_base
SHOW_INITIAL_ROWS = TRUE; 


CREATE STREAM emp_stream ON TABLE emp_base;
SELECT *, METADATA$ACTION
FROM emp_stream;


INSERT INTO emp_base (EmpID, Name, Department, Salary) VALUES
(1011, 'Alice', 'HR', 50000),
(1022, 'Bob', 'Finance', 60000),
(1033, 'Charlie', 'IT', 70000);

UPDATE emp_base
SET Salary = 70000
WHERE EmpID = 1011;

DELETE FROM emp_base
WHERE EmpID = 1033;
SHOW STREAMS;



update emp_base()



