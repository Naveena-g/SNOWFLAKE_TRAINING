USE WAREHOUSE COMPUTE_WH;
USE DATABASE OUR_FIRST_DB;
USE SCHEMA PUBLIC;
USE WAREHOUSE COMPUTE_WH;

CREATE OR REPLACE DATABASE OUR_FIRST_DB;
USE DATABASE OUR_FIRST_DB;
CREATE OR REPLACE SCHEMA TRAINING;
USE SCHEMA TRAINING;
PUT file://C:/Data/student.csv @~;

CREATE OR REPLACE FILE FORMAT my_csv_format
TYPE = 'CSV'
FIELD_OPTIONALLY_ENCLOSED_BY = '"'
SKIP_HEADER = 1
FIELD_DELIMITER = ',';

create or replace stage aws_stage1 url ='s3://naveena-snowflakebkt43' credentials= (aws_key_id='AKIAXIEJSK4FUMVJH3MY' aws_secret_key='NySjYPz/txvshuYqfqXFpZWS0LtYaaHt/J0iFnE4 ');

copy into flowers_dataset from @aws_stage1/flowers_dataset.csv
file_format='my_csv_format'
purge=true;

select count(*)from flowers_dataset;
select *from flowers_dataset;

SHOW TABLES LIKE 'FLOWERS_DATASET';
COPY INTO flowers_dataset
FROM @aws_stage1/flowers_dataset_data.csv
FILE_FORMAT = 'my_csv_format'
VALIDATION_MODE = 'RETURN_ERRORS';

SELECT CURRENT_DATABASE(), CURRENT_SCHEMA();
SELECT $1, $2, $3, $4, $5, $6, $7
FROM @aws_stage1/flowers_dataset_data.csv
(FILE_FORMAT => 'my_csv_format')
LIMIT 5;

COPY INTO flowers_dataset
FROM @aws_stage1/flowers_dataset.csv
FILE_FORMAT = (FORMAT_NAME = 'my_csv_format')
ON_ERROR = 'CONTINUE';


GET @my_stage/employee_dataset.csv file://C:\data\;