CREATE or replace database 
shared_sales_db from share XDGOXKY.SD29507.sales_share;