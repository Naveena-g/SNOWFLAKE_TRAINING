create or replace table sales_data(
    order_id int,
    product_name string,
    amount number(10,2),
    order_date Date
) data_retention_time_in_days=5;

show tables like 'LOAN%';

alter table LOAN_PAYMENT set data_retention_time_in_days=5;

create or replace transient table sales_data1(
    order_id int,
    product_name string,
    amount number(10,2),
    order_date Date
);
show tables;

alter table sales_data1 set data_retention_time_in_days=5;

create or replace temporary table sales_data2(
    order_id int,
    product_name string,
    amount number(10,2),
    order_date Date
);

create or replace external table sales_data3(
    order_id int,
    product_name string,
    amount number(10,2),
    order_date Date
);

select * from loan_payment;

CREATE OR REPLACE EXTERNAL TABLE LOAN_PAYMENT_EXT (
    Loan_ID STRING AS (VALUE:c1::STRING),
    loan_status STRING AS (VALUE:c2::STRING),
    Principal STRING AS (VALUE:c3::STRING),
    terms STRING AS (VALUE:c4::STRING),
    effective_date STRING AS (VALUE:c5::STRING),
    due_date STRING AS (VALUE:c6::STRING),
    paid_off_time STRING AS (VALUE:c7::STRING),
    past_due_days STRING AS (VALUE:c8::STRING),
    age STRING AS (VALUE:c9::STRING),
    education STRING AS (VALUE:c10::STRING),
    Gender STRING AS (VALUE:c11::STRING)
)
WITH LOCATION = @aws_stage1/Loan_payments_data.csv
FILE_FORMAT = (TYPE = CSV SKIP_HEADER = 1 FIELD_OPTIONALLY_ENCLOSED_BY = '"');
        

create view loan_payment_view as select * from loan_payment;

create or replace materialized view category_sum
as select category, sum(amount) as total_amount,
                    sum(profit) as total_profit,
                    sum(quantity) as total_quantity
                    from orders group by category;

select * from category_sum order by TOTAL_AMOUNT desc;

update orders set amount =amount+10000 where category ='Furniture';

insert into orders values('A-20000',400,200,9,'hhold','hhold');
show materialized views;





