CREATE OR REPLACE DATABASE amutha;
CREATE SCHEMA kacs;
use amutha;
use SCHEMA kacs;
