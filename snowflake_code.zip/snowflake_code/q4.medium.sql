CREATE OR REPLACE TRANSIENT TABLE sales_trans (
OrderID varchar,Item String,Quantity int,Amount int
);
CREATE OR REPLACE temporary TABLE sales_temp (
OrderID varchar,Item String,Quantity int,Amount int
);
CREATE OR REPLACE TABLE sales_perm (
OrderID varchar,Item String,Quantity int,Amount int
);

COPY INTO sales_perm
FROM @~/sales.csv
FILE_FORMAT = (FORMAT_NAME = my_csv_format)
ON_ERROR = 'CONTINUE';

-- 3. Create file format (if you haven't already)
CREATE OR REPLACE FILE FORMAT my_csv_format
  TYPE = 'CSV'
  FIELD_DELIMITER = ','
  SKIP_HEADER = 1
  NULL_IF = ('NULL','null')
  FIELD_OPTIONALLY_ENCLOSED_BY = '"';


desc table sales_trans;
SHOW TABLES LIKE 'sales_%';



DELETE FROM sales_perm WHERE OrderID='O101';
DELETE FROM sales_trans WHERE OrderID='O101';
DELETE FROM sales_temp WHERE OrderID='O101';


SELECT * FROM sales_perm AT (OFFSET => -600); 
SELECT * FROM sales_trans AT (OFFSET => -600); 
SELECT * FROM sales_temp AT (OFFSET => -600); 

select * from sales_temp;
select * from sales_trans;
select * from sales_perm;

INSERT INTO sales_perm
SELECT *
FROM sales_perm
AT (OFFSET => -600)
WHERE OrderID = 'O101';

INSERT INTO sales_temp
SELECT *
FROM sales_temp
AT (OFFSET => -600)
WHERE OrderID = 'O101';

-- ====================
CREATE OR REPLACE temporary TABLE temp_products (
PID varchar,Stock String,PTypes String,Amount int
);

COPY INTO temp_products
FROM @~/products.csv
FILE_FORMAT = (TYPE = 'CSV' FIELD_OPTIONALLY_ENCLOSED_BY='"' SKIP_HEADER=1);

show tables like 'emp_transient';
select * from emp_transient;

CREATE OR REPLACE transient TABLE emp_transient (
EMPID varchar,Name String,Department String,Salary int
);
PUT file://C:\test\employees_data.csv @%emp_transient;

COPY INTO emp_transient
FROM @%emp_transient
FILE_FORMAT = (FORMAT_NAME = my_csv_format)
ON_ERROR = 'CONTINUE';

select * from emp_transient;


