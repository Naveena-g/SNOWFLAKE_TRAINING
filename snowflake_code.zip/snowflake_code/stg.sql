
USE WAREHOUSE COMPUTE_WH;
USE DATABASE OUR_FIRST_DB;
USE SCHEMA PUBLIC;

-- confirm
SELECT CURRENT_DATABASE(), CURRENT_SCHEMA(), CURRENT_WAREHOUSE();

create stage my_stage;
list @my_stage;
show stages;
desc stage my_stage;

USE DATABASE OUR_FIRST_DB;
USE SCHEMA TRAINING;

SHOW TABLES;

CREATE TABLE LOAN_PAYMENT (
    Loan_ID STRING,
    loan_status STRING,
    Principal STRING,
    terms STRING,
    effective_date STRING,
    due_date STRING,
    paid_off_time STRING,
    past_due_days STRING,
    age STRING,
    education STRING,
    "Gender" STRING
);
select * from LOAN_PAYMENT;

COPY INTO LOAN_PAYMENT
FROM 's3://bucketsnowflakes3/Loan_payments_data.csv'
FILE_FORMAT = (TYPE = 'CSV' FIELD_DELIMITER = ',' SKIP_HEADER = 1);

truncate table LOAN_PAYMENT;

COPY INTO LOAN_PAYMENT
FROM 's3://bucketsnowflakes3/Loan_payments_data.csv'
FILE_FORMAT = (format_name='my_csv_format');


create or replace stage aws_stage
    url='s3://bucketsnowflakes3'
    credentials =(aws_key_id='ABCD_DUMMY_ID' aws_secret_key='1234abcd_key')
 
desc stage aws_stage;

list @aws_stage;

alter stage aws_stage 
     set credentials = (aws_key_id='XYZ_DUMMY_ID' aws_secret_key ='987xyz');

create or replace stage aws_stage
    url='s3://bucketsnowflakes3';

CREATE TABLE ORDERS (Order_ID STRING,
            Amount INT,	
            Profit INT,	
            Quantity INT,	
            Category STRING,	
            Sub_Category STRING);
desc table ORDERS; 

select $1 ORDER_ID,
    $2 AMOUNT,
    $3 PROFIT,
    $4 QUANTITY,
    $5 CATEGORY,
    $6 SUB_CATEGORY
FROM @aws_stage/OrderDetails.csv;

COPY INTO ORDERS
FROM @aws_stage
FILE_FORMAT = (TYPE = 'CSV' FIELD_DELIMITER = ',' SKIP_HEADER = 1)
PATTERN = '.*Order.*';


truncate ORDERS;
    
CREATE OR REPLACE TABLE ORDERS_EX(
ORDER_ID VARCHAR(30),
AMOUNT INT
);

COPY INTO ORDERS_EX 
FROM (SELECT S.$1, S.$2 FROM @aws_stage s)
file_format='my_csv_format'
files=('OrderDetails.csv');

select * from orders_ex;

truncate table orders_ex;
CREATE OR REPLACE TABLE ORDERS_EX (
    ORDER_ID VARCHAR(30),
    AMOUNT INT,
    PROFIT INT,
    PROFITABLE_FLAG VARCHAR(30)
  
    );

COPY INTO ORDERS_EX (order_id,amount)
FROM (SELECT $1, $2 FROM @aws_stage)
file_format='my_csv_format'
files=('OrderDetails.csv');

select * from orders;
select * from ORDERS_EX;
TRUNCATE TABLE ORDERS_EX;
copy into ORDERS_EX
from (select $1,$2,$3, case when cast($3 as int )< 0 then 'not profitable' else 'profitable' end from @aws_stage)
file_format ='my_csv_format'
files=('OrderDetails.csv');

CREATE OR REPLACE TABLE ORDERS_EX (
    ORDER_ID VARCHAR(30),
    AMOUNT INT,
    PROFIT_STATUS VARCHAR(20),  -- increased from 5 to 20
    CATEGORY_SUBSTRING VARCHAR(5)
);

desc table ORDERS_EX;

select * from ORDERS_EX;

copy into ORDERS_EX
from (select $1,$2,$3, substring($5,1,5) from @aws_stage)
file_format ='my_csv_format'
files=('OrderDetails.csv');


select * from snowflake.account_usage.load_history;

create or replace table ORDERS_EX(
    ORDER_ID NUMBER AUTOINCREMENT START 1 INCREMENT 1,
    AMOUNT INT,
    PROFIT INT,
    PROFITABLE_FLAG VARCHAR(30));

TRUNCATE TABLE ORDERS_EX;
SELECT * FROM ORDERS_EX;




 CREATE OR REPLACE STAGE aws_stage_errorex
    url='s3://bucketsnowflakes4';
LIST @aws_stage_errorex;

copy into orders
from @aws_stage_errorex
file_format='MY_CSV_FORMAT'
FILES =('OrderDetails_error.csv')
on_error='continue';

select count(*) from orders;




copy into orders
from @aws_stage_errorex
file_format='MY_CSV_FORMAT'
FILES =('OrderDetails_error.csv','OrderDetails_error2.csv')
on_error='skip_file';
select count(*) from orders;

TRUNCATE TABLE orders;
copy into orders
from @aws_stage_errorex
file_format='MY_CSV_FORMAT'
on_error='skip_file_3';
select count(*) from orders;


TRUNCATE TABLE orders;
copy into orders
from @aws_stage_errorex
file_format='MY_CSV_FORMAT'
on_error='skip_file_3'
size_limit =30;
select count(*) from orders;


TRUNCATE TABLE orders;

COPY INTO orders
FROM @aws_stage_errorex
FILE_FORMAT = (TYPE = 'CSV' FIELD_DELIMITER = ',')
FILES = ('OrderDetails_error.csv','OrderDetails_error2.csv')
ON_ERROR = 'SKIP_FILE';

SELECT COUNT(*) FROM orders;

CREATE OR REPLACE STAGE aws_stage_copy
    url='s3://snowflakebucket-copyoption/returnfailed/';

truncate table ORDERS;
CREATE OR REPLACE TABLE  ORDERS (
    ORDER_ID VARCHAR(30),
    AMOUNT VARCHAR(30),
    PROFIT INT,
    QUANTITY INT,
    CATEGORY VARCHAR(10),
    SUBCATEGORY VARCHAR(30));

list @aws_stage;
COPY INTO orders
FROM @aws_stage_copy
FILE_FORMAT = 'my_csv_format'
pattern='.*Order.*';

COPY INTO orders
FROM @aws_stage
FILE_FORMAT = 'my_csv_format'
pattern='.*Order.*';

COPY INTO orders
FROM @aws_stage_copy
FILE_FORMAT = 'my_csv_format'
pattern='.*Order.*';# this show error use below

COPY INTO orders
FROM @aws_stage
FILE_FORMAT = 'my_csv_format'
pattern='.*Order.*'
truncatecolumns=true;

COPY INTO ORDERS
FROM @aws_stage_copy
FILE_FORMAT = (TYPE = 'CSV' FIELD_DELIMITER = ',' SKIP_HEADER = 1)
PATTERN = '.*Order.*'
ON_ERROR = 'CONTINUE'
FORCE = TRUE;


select * from information_schema_load_history
order by last_load_time desc;

SELECT *
FROM TABLE(INFORMATION_SCHEMA.COPY_HISTORY(
        table_name => 'ORDERS',      -- the table you loaded
        start_time => DATEADD(day, -7, CURRENT_TIMESTAMP),  -- last 7 days
        end_time   => CURRENT_TIMESTAMP
    ))
ORDER BY LAST_LOAD_TIME DESC;








