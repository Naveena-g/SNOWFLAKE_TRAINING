CREATE OR REPLACE FILE FORMAT csv_format_customer
TYPE = 'CSV'
FIELD_OPTIONALLY_ENCLOSED_BY='"'
SKIP_HEADER=1
FIELD_DELIMITER=',';


create or replace stage s3_stage_customer url ='s3://naveena-s3-customer-bucket' credentials= (aws_key_id='AKIAXIEJSK4FYC34CY4X' 
aws_secret_key='/07q0nh6/kExvCxUJrFpQC2ICEw/OOS8b4bAMT+G') FILE_FORMAT=csv_format_customer;

list @s3_stage_customer;
SHOW STAGES;



CREATE OR REPLACE TABLE customers_orders (
    OrderId INT,
    CustomerID STRING,
    OrderAmount FLOAT,
    OrderDate DATE,
    Status STRING
);

CREATE OR REPLACE TABLE load_audit (
    FileName STRING,
    LoadTimestamp TIMESTAMP,
    RecordCount INT
);


COPY INTO customers_orders
FROM @s3_stage_customer/customers_orders.csv
FILE_FORMAT = (FORMAT_NAME = csv_format_customer)
ON_ERROR = 'CONTINUE';

select * from load_audit;


















