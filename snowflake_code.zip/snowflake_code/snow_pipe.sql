CREATE OR REPLACE FILE FORMAT my_csv_format
  TYPE = 'CSV'
  FIELD_DELIMITER = ','
  SKIP_HEADER = 1
  FIELD_OPTIONALLY_ENCLOSED_BY = '"';

create or replace storage integration s3_int
  TYPE = EXTERNAL_STAGE
  STORAGE_PROVIDER = S3
  ENABLED = TRUE 
  STORAGE_AWS_ROLE_ARN = 'arn:aws:iam::498504718091:role/naveena_s3_snowflake'
  STORAGE_ALLOWED_LOCATIONS = ('s3://naveena-snowflakebkt43/csv/')
  COMMENT = 'This an optional comment' ;

desc integration s3_int;

CREATE OR REPLACE stage csv_folder
URL = 's3://naveena-snowflakebkt43/csv/'
STORAGE_INTEGRATION = s3_int
FILE_FORMAT = my_csv_format;

list @csv_folder;

    CREATE OR REPLACE TABLE ORDERS (
    ORDER_ID VARCHAR(30),
    AMOUNT INT,
    PROFIT INT,
    QUANTITY INT,
    CATEGORY VARCHAR(30),
    SUBCATEGORY VARCHAR(30));

copy into ORDERS from @csv_folder/OrderDetails.csv
purge=true;

select * from ORDERS;
-- =======================================================================

CREATE OR REPLACE pipe orders_pipe
auto_ingest = TRUE
AS
COPY INTO orders
FROM @csv_folder;

desc pipe orders_pipe;
truncate table ORDERS;
select * from ORDERS;

select * from table (information_schema.copy_history
(table_name => 'orders',
start_time => dateadd('hour',-24,current_timestamp())));

