show parameters like 'TIMEZONE';
alter session set timezone='Asia/Kolkata';

CREATE OR REPLACE STAGE time_travel_stage
    URL = 's3://data-snowflake-fundamentals/time-travel/'
    file_format = my_csv_format;
    
CREATE OR REPLACE TABLE test (
   id int,
   first_name string,
  last_name string,
  email string,
  gender string,
  Job string,
  Phone string);

copy into test from @time_travel_stage;

select * from test;

update test set FIRST_NAME='Joyen';

select * from test at (OFFSET => -100);

CREATE OR REPLACE table test1 as select * from test at (OFFSET => -100*3);

select * from test;
select * from test1;

truncate table test;
truncate table test1;

insert into test select * from test1;

update test set job ='Data Engineer';

select * from OUR_FIRST_DB.PUBLIC.test before (statement => '01bfa215-3201-ff2c-0010-872200019b1e');

create table test2 clone OUR_FIRST_DB.PUBLIC.test before (statement => '01bfa215-3201-ff2c-0010-872200019b1e');

drop table test;
select * from test;
undrop table test;

drop schema public;
show schemas;
select * from  OUR_FIRST_DB.PUBLIC.test;
undrop schema public;

drop database OUR_FIRST_DB;
show databases;
use OUR_FIRST_DB;
undrop database OUR_FIRST_DB;
use OUR_FIRST_DB.public;

show tables;

drop stage @


