CREATE OR REPLACE FILE FORMAT my_csv_format
  TYPE = 'CSV'
  FIELD_DELIMITER = ','
  SKIP_HEADER = 1
  FIELD_OPTIONALLY_ENCLOSED_BY = '"';

  create or replace storage integration nave_int
  TYPE = EXTERNAL_STAGE
  STORAGE_PROVIDER = S3
  ENABLED = TRUE 
  STORAGE_AWS_ROLE_ARN = 'arn:aws:iam::498504718091:role/chotta_beam'
  STORAGE_ALLOWED_LOCATIONS = ('s3://naveena-rough-use/xyz/')
  COMMENT = 'This an optional comment' ;

describe integration nave_int;
list @nave_stage;

CREATE OR REPLACE stage nave_stage
URL = 's3://naveena-rough-use/xyz/'
STORAGE_INTEGRATION = nave_int
FILE_FORMAT = my_csv_format;

list @nave_stage;

CREATE OR REPLACE TABLE f (
    FlowerID INT ,
    FlowerName VARCHAR(50),
    Color VARCHAR(20),
    PetalLength_cm FLOAT,
    PetalWidth_cm FLOAT,
    StemLength_cm INT,
    Price INT
);

CREATE OR REPLACE PIPE load_flowers_new_only
AUTO_INGEST = TRUE
AS
COPY INTO f
FROM @nave_stage
FILE_FORMAT = (FORMAT_NAME = my_csv_format)
ON_ERROR = 'CONTINUE';

DESC PIPE load_flowers_new_only;

select * from f;

select * from table (information_schema.copy_history
(table_name => 'f',
start_time => dateadd('hour',-1,current_timestamp())));















