SELECT 
    TABLE_CATALOG AS DATABASE_NAME,
    TABLE_SCHEMA,
    TABLE_NAME,
    ACTIVE_BYTES / 1024 / 1024 AS ACTIVE_MB,
    TIME_TRAVEL_BYTES / 1024 / 1024 AS TIME_TRAVEL_MB,
    FAILSAFE_BYTES / 1024 / 1024  AS FAILSAFE_MB,
    (ACTIVE_BYTES + TIME_TRAVEL_BYTES + FAILSAFE_BYTES) / 1024 / 1024  AS TOTAL_MB
FROM SNOWFLAKE.ACCOUNT_USAGE.TABLE_STORAGE_METRICS WHERE TABLE_NAME ='TEST'
ORDER BY TIME_TRAVEL_BYTES DESC;

create table loan_payment_clone clone loan_payment;
desc table loan_payment_clone;

show tables like 'loan_payment_clone';
select * from loan_payment_clone;

update loan_payment_clone set EDUCATION = 'High School' where EDUCATION = 'High School or Below';

select * from loan_payment_clone  where EDUCATION = 'High School';

delete from loan_payment where EDUCATION = 'High School or Below';

create schema public_schema clone public;

use schema public_schema;

show tables;
drop table loan_payment_clone;
use schema public;

create database our_first_db_c clone our_first_db;

show databases;

create table test_clone clone test at (offset =>- (4*60*60))






















