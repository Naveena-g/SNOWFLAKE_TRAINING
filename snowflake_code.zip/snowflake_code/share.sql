create share sales_share;
show shares;
GRANT USAGE ON DATABASE OUR_FIRST_DB TO SHARE SALES_SHARE;
GRANT USAGE ON SCHEMA OUR_FIRST_DB.PUBLIC TO SHARE SALES_SHARE;
GRANT SELECT ON ALL TABLES IN SCHEMA OUR_FIRST_DB.PUBLIC TO SHARE SALES_SHARE;



CREATE database shared_sales_db from share XDGOXKY.SD29507.sales_share;
use shared_sales_db;

alter share sales_share add accounts= XDGOXKY.SD29507;
SELECT * FROM ORDERS;

Show shares;
show grants to share sales_share;

alter share sales_share REMOVE accounts = XDGOXKY.SD29507;

CREATE MANAGED ACCOUNT reader_partner1
  ADMIN_NAME = 'reader_admin'
  ADMIN_PASSWORD = 'Reader@123___90'
  TYPE = READER;

SHOW MANAGED ACCOUNTS;

alter share sales_share add accounts= CQ27444;

CREATE OR REPLACE WAREHOUSE a
  WAREHOUSE_SIZE = 'XSMALL'
  AUTO_SUSPEND = 60
  AUTO_RESUME = TRUE
  INITIALLY_SUSPENDED = TRUE;
  
