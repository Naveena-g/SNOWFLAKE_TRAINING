create or replace stage kiyo url ='s3://naveena-rough-use' credentials= (aws_key_id='AKIAXIEJSK4FYC34CY4X' aws_secret_key='/07q0nh6/kExvCxUJrFpQC2ICEw/OOS8b4bAMT+G');

list @kiyo;
SHOW STAGES;

CREATE OR REPLACE FILE FORMAT my_csv_format
TYPE = 'CSV'
FIELD_OPTIONALLY_ENCLOSED_BY='"'
SKIP_HEADER=1
FIELD_DELIMITER=',';

CREATE OR REPLACE TABLE flowers_dataset (
    FlowerID INT PRIMARY KEY,
    FlowerName VARCHAR(50),
    Color VARCHAR(20),
    PetalLength_cm FLOAT,
    PetalWidth_cm FLOAT,
    StemLength_cm INT,
    Price INT
);

copy into flowers_dataset from @kiyo/flowers_dataset.csv
file_format='my_csv_format'
purge=true;
select count(*)from OrderDetails;
select *from flowers_dataset;


CREATE OR REPLACE TABLE employee_dataset (
    Employee_ID STRING,
    Name STRING,
    Age INT,
    Department STRING,
    Salary INT,
    Join_Date DATE,
    City STRING
);

copy into employee_dataset from @aws_stage1/employee_dataset.csv
file_format='my_csv_format'
purge=true;
select count(*)from employee_dataset;
select *from employee_dataset;


copy into @aws_stage1/employee_dataset_backup from employee_dataset
file_format=type=''

COPY INTO @aws_stage1/employee_dataset_backup
FROM employee_dataset
FILE_FORMAT = (TYPE = 'CSV' FIELD_DELIMITER = ',' HEADER = TRUE);