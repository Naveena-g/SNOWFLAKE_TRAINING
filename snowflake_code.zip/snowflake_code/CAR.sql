select price from car_dataset;

CREATE or replace transient TABLE car_data (
    Brand VARCHAR(50),
    Model VARCHAR(50),
    Year INT,
    Price DECIMAL(10,2),
    Fuel_Type VARCHAR(20),
    Transmission VARCHAR(20),
    Color VARCHAR(30)
);

show tables like'car_data';