use database our_first_db;
use schema public;

CREATE OR REPLACE FILE FORMAT my_csv_format
TYPE = 'CSV'
FIELD_OPTIONALLY_ENCLOSED_BY='"'
SKIP_HEADER=1
FIELD_DELIMITER=',';

create or replace stage my_ns_buck_stage1 url ='s3://navee-s3-buck' credentials= (aws_key_id='AKIAQXHTY4A4NSHHQNVR' aws_secret_key='5q1xx8ZENcr53YZRYnBtl3nS7U00fv6dH8nNo13o');

list @my_ns_buck_stage1;
SHOW STAGES;

create or replace stage my_ns_re_buck_stage2 url ='s3://naveena-result-buck ' credentials= (aws_key_id='AKIAQXHTY4A4EGO72RGF' aws_secret_key='iAZJi0Y5ZUJhUJ/BmHr9lRLrlakOGN/QcLPAOhbg');

