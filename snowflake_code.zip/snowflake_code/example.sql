-- Step 1: Set your working environment
USE ROLE SYSADMIN;
USE WAREHOUSE COMPUTE_WH;
CREATE OR REPLACE DATABASE PRACTICE_DB;
USE DATABASE PRACTICE_DB;
create or replace schema LAB_SCHEMA;
USE SCHEMA LAB_SCHEMA;

select * from CUSTOMER_DATA;
create or replace stage aws_stage1 url ='s3://naveena-snowflakebkt43' credentials= (aws_key_id='AKIAXIEJSK4FUMVJH3MY' aws_secret_key='NySjYPz/txvshuYqfqXFpZWS0LtYaaHt/J0iFnE4 ');


SHOW STAGES;
list @aws_stage1;

CREATE OR REPLACE TRANSIENT TABLE department_data (
  DEPT_ID string,
  DEPT_NAME STRING,
  LOCATION STRING
);

CREATE OR REPLACE FILE FORMAT my_csv_format
  TYPE = 'CSV'
  FIELD_DELIMITER = ','
  SKIP_HEADER = 1
  NULL_IF = ('NULL', 'null')
  FIELD_OPTIONALLY_ENCLOSED_BY = '"';


LIST @aws_stage1;
copy into department_data from @aws_stage1/department_data.csv
file_format='my_csv_format'
purge=true;


PUT file://C:/Data/department_data.csv @%DEPT_TRANSIENT AUTO_COMPRESS=FALSE;


-- 2️⃣ Students Table
CREATE OR REPLACE TRANSIENT TABLE student_trans (
  STUDENT_ID INT,
  STUDENT_NAME STRING,
  DEPARTMENT STRING
);

-- 3️⃣ Customer Table
CREATE OR REPLACE TRANSIENT TABLE cust_transient (
  CUST_ID INT,
  CUST_NAME STRING,
  CITY STRING
);

-- 4️⃣ Employee Info Table
CREATE OR REPLACE TRANSIENT TABLE emp_info_trans (
  EMP_ID INT,
  EMP_NAME STRING,
  DESIGNATION STRING,
  SALARY NUMBER(10,2)
);

-- 5️⃣ Supplier Table
CREATE OR REPLACE TRANSIENT TABLE supplier_trans (
  SUPPLIER_ID INT,
  SUPPLIER_NAME STRING,
  CITY STRING,
  CONTACT_NUMBER STRING
);

show tables;



-- =============================================
-- 4️⃣ Upload CSV files to table stages
-- =============================================

-- DEPT_TRANSIENT
PUT file://C:/Data/department_data.csv @%DEPT_TRANSIENT AUTO_COMPRESS=FALSE;

-- STUDENT_TRANS
PUT file://C:/Data/students.csv @%STUDENT_TRANS AUTO_COMPRESS=FALSE;

-- CUST_TRANSIENT
PUT file://C:/Data/customer_data.csv @%CUST_TRANSIENT AUTO_COMPRESS=FALSE;

-- EMP_INFO_TRANS
PUT file://C:/Data/employee_data.csv @%EMP_INFO_TRANS AUTO_COMPRESS=FALSE;

-- SUPPLIER_TRANS
PUT file://C:/Data/products.csv @%SUPPLIER_TRANS AUTO_COMPRESS=FALSE;

-- =============================================
-- 5️⃣ Load CSV into tables using COPY INTO
-- =============================================

-- DEPT_TRANSIENT
COPY INTO DEPT_TRANSIENT
FROM @%DEPT_TRANSIENT/department_data.csv
FILE_FORMAT = (TYPE='CSV' SKIP_HEADER=1 FIELD_OPTIONALLY_ENCLOSED_BY='"');

-- STUDENT_TRANS
COPY INTO STUDENT_TRANS
FROM @%STUDENT_TRANS/students.csv
FILE_FORMAT = (TYPE='CSV' SKIP_HEADER=1 FIELD_OPTIONALLY_ENCLOSED_BY='"');

-- CUST_TRANSIENT
COPY INTO CUST_TRANSIENT
FROM @%CUST_TRANSIENT/customer_data.csv
FILE_FORMAT = pipe_format;

-- EMP_INFO_TRANS
COPY INTO EMP_INFO_TRANS
FROM @%EMP_INFO_TRANS/employee_data.csv
FILE_FORMAT = (TYPE='CSV' SKIP_HEADER=1 FIELD_OPTIONALLY_ENCLOSED_BY='"');

-- SUPPLIER_TRANS
COPY INTO SUPPLIER_TRANS
FROM @%SUPPLIER_TRANS/products.csv
FILE_FORMAT = supplier_fmt;

-- =============================================
-- 6️⃣ Verify Data Loaded
-- =============================================

SELECT 'DEPT_TRANSIENT' AS TABLE_NAME, COUNT(*) AS ROW_COUNT FROM DEPT_TRANSIENT
UNION ALL
SELECT 'STUDENT_TRANS', COUNT(*) FROM STUDENT_TRANS
UNION ALL
SELECT 'CUST_TRANSIENT', COUNT(*) FROM CUST_TRANSIENT
UNION ALL
SELECT 'EMP_INFO_TRANS', COUNT(*) FROM EMP_INFO_TRANS
UNION ALL
SELECT 'SUPPLIER_TRANS', COUNT(*) FROM SUPPLIER_TRANS;

-- Optional: Preview first 5 rows of each table
SELECT * FROM DEPT_TRANSIENT LIMIT 5;
SELECT * FROM STUDENT_TRANS LIMIT 5;
SELECT * FROM CUST_TRANSIENT LIMIT 5;
SELECT * FROM EMP_INFO_TRANS LIMIT 5;
SELECT * FROM SUPPLIER_TRANS LIMIT 5;



