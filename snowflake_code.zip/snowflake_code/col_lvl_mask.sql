create or replace role full_access_role;
create or replace role limited_role;

grant usage on warehouse compute_wh to full_access_role;
grant usage on warehouse compute_wh to limited_role;
grant usage on database our_first_db to full_access_role;
grant usage on database our_first_db  to limited_role;
grant usage on schema our_first_db.public to full_access_role;
grant usage on schema our_first_db.public to limited_role;

create or replace table our_first_db.public.emp(id int,name varchar(20), email varchar(30));

insert into our_first_db.public.emp values(1,'ram','ram@gmail.com'),(2,'sham','sham@gmail.com'),(3,'sruthi','sruthi@gmail.com');

grant select on  our_first_db.public.emp to role full_access_role;
grant select on  our_first_db.public.emp to role limited_role;

rev select on  our_first_db.public.emp to role us_region_role;
grant select on  our_first_db.public.emp to role eu_region_role;

 grant role us_region_role to user us_user;

create user full_user identified by 'admin123' default_role =full_access_role;
create user limited_user identified by 'admin123' default_role =limited_role;

drop user limited_user;
drop user full_user;

grant role full_access_role to user full_user;
grant role limited_role to user limited_user;

CREATE OR REPLACE COLUMN ACCESS POLICY salary_policy
  AS (val NUMBER)
  RETURNS NUMBER ->
  CASE
    WHEN CURRENT_ROLE() IN ('ACCOUNTADMIN','FULL_ACCESS_ROLE') THEN val
    ELSE NULL
  END;


CREATE OR REPLACE MASKING POLICY Col_policy1 
  AS (val STRING) RETURNS STRING ->
  CASE
    WHEN CURRENT_ROLE() IN ('ACCOUNTADMIN','FULL_ACCESS_ROLE','us_region_role') THEN val
    ELSE
    NULL
  END;

  alter table emp modify column name set masking policy Col_policy1;