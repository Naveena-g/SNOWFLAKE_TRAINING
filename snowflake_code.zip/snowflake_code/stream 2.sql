-- ============================================================
-- 🔧 STEP 1: SETUP - Create File Format and Stage
-- ============================================================

CREATE OR REPLACE FILE FORMAT my_csv_format 
TYPE = 'CSV'
FIELD_OPTIONALLY_ENCLOSED_BY='"'
SKIP_HEADER = 1;

CREATE OR REPLACE STAGE emp_stage;

-- ============================================================
-- 🧱 STEP 2: CREATE TABLES
-- ============================================================

-- Base (Landing) Table
CREATE OR REPLACE TABLE emp_base (
    EmpID INT,
    Name STRING,
    Department STRING,
    Salary INT
);

-- Final (Processed) Table
CREATE OR REPLACE TABLE emp_final (
    EmpID INT,
    Name STRING,
    Department STRING,
    Salary INT
);

-- ============================================================
-- 🔍 STEP 3: CREATE STREAM ON BASE TABLE
-- ============================================================

CREATE OR REPLACE STREAM emp_stream 
ON TABLE emp_base;

-- ============================================================
-- ⚙️ STEP 4: TASK 1 - LOAD DATA FROM STAGE → BASE TABLE
-- ============================================================

CREATE OR REPLACE TASK emp_load_task
WAREHOUSE = COMPUTE_WH
SCHEDULE = 'USING CRON */5 * * * * Asia/Kolkata'  -- runs every 5 mins
AS
    COPY INTO emp_base
    FROM @emp_stage
    FILE_FORMAT = (FORMAT_NAME = my_csv_format)
    ON_ERROR = 'CONTINUE';

-- ============================================================
-- 🔄 STEP 5: TASK 2 - MOVE STREAM DATA → FINAL TABLE
-- ============================================================

CREATE OR REPLACE TASK emp_stream_task
WAREHOUSE = COMPUTE_WH
AFTER emp_load_task
WHEN
    SYSTEM$STREAM_HAS_DATA('emp_stream')
AS
    INSERT INTO emp_final (EmpID, Name, Department, Salary)
    SELECT EmpID, Name, Department, Salary
    FROM emp_stream;

-- ============================================================
-- ▶️ STEP 6: ENABLE TASKS
-- ============================================================

ALTER TASK emp_load_task RESUME;
ALTER TASK emp_stream_task RESUME;

-- ============================================================
-- 🧪 STEP 7: TEST EXECUTION (Optional Manual Trigger)
-- ============================================================

-- You can upload your CSV manually first:
-- PUT file://C:\data\emp_data.csv @emp_stage;

-- Then run these manually to test:
-- EXECUTE TASK emp_load_task;
-- EXECUTE TASK emp_stream_task;

-- ============================================================
-- 📊 STEP 8: VALIDATION AND MONITORING
-- ============================================================

-- View data at each step
-- SELECT * FROM emp_base;
-- SELECT * FROM emp_stream;
-- SELECT * FROM emp_final;

-- Check if stream has pending changes
-- SELECT SYSTEM$STREAM_HAS_DATA('emp_stream') AS stream_status;

-- View tasks and dependencies
-- SHOW TASKS;

-- Task run history
-- SELECT * 
-- FROM TABLE(INFORMATION_SCHEMA.TASK_HISTORY())
-- ORDER BY COMPLETED_TIME DESC;
