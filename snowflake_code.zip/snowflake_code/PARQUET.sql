CREATE OR REPLACE FILE FORMAT PARQUET_FORMAT
TYPE ='parquet';

create or replace stage pstage url ='s3://naveena-snowflakebkt43/PARQUET/' FILE_FORMAT=PARQUET_FORMAT credentials= (aws_key_id='AKIAXIEJSK4FUMVJH3MY' aws_secret_key='NySjYPz/txvshuYqfqXFpZWS0LtYaaHt/J0iFnE4 ');

LIST @pstage;
SELECT $1 FROM @pstage;

select 
$1:cat_id,
$1:"d",
$1:"date",
$1:"dept_id",
$1:"id",
$1:"item_id",
$1:"state_id",
$1:"store_id",
$1:"value"
from @pstage;
show parameters like 'TIMEZONE';
alter session set timezone='Asia/Kolkata';

create or replace table parquet_data as 
select 
$1:cat_id::varchar(50) as category,
date($1:date::int) as date,
$1:"dept_id"::varchar(50) as dept_id,
$1:"id"::varchar(50) as id,
$1:"item_id":: varchar(50) as item_id,
$1:"state_id":: varchar(50) as state_id,
$1:"store_id":: varchar(50) as store_id,
$1:"value":: int as value,

metadata$filename as filename,
metadata$file_row_number as rownumber,
to_timestamp_ntz(current_timestamp) as tim,
current_timestamp as load_time
from @pstage;

select * from parquet_data;
create or replace table parq as select * from parquet_data where 10=20;

select * from parq;












